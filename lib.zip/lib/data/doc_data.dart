     List<Map<String, dynamic>> docs = [
  {
        "name": "ID front view",
        "image": "assets/images/id.png"
  },
  {
    
    "name": "ID back view",
    "image": "assets/images/back_id.png"
  },
  {
 
    "name": "personal photo",
    "image": "assets/images/back_id.png"
  }

];
