import 'package:flutter/material.dart';

class AppColors {
  static const darkTeal = Color(0xFF285260);
  static const mediumTeal = Color(0xFF5A9C92);
  static const lightAqua = Color(0xFFB4D7D8);
  static const tanBrown = Color(0xFFAA8872);
}
